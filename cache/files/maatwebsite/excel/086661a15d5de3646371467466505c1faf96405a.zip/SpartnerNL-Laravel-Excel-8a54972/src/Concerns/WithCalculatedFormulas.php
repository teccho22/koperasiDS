<?php

namespace Maatwebsite\Excel\Concerns;

interface WithCalculatedFormulas
{
}
